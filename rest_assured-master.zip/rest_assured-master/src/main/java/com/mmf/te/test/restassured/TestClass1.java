package com.mmf.te.test.restassured;

import org.junit.Test;
import static com.jayway.restassured.RestAssured.given;

public class TestClass1 extends FunctionalTest {


    final Integer exchangeId =  47;

    @Test
    public void getTopExpByExchId() {
        given().when().get("/v1/m/top_exp/"+exchangeId+"/0").then().statusCode(200);
    }

    @Test
    public void getTopExpSummaryByExperId() {
        given().when().get("/v1/m/top_exp/summary/108/0").then().statusCode(200);
    }

    @Test
    public void getBookingCatListByExchId() {
        given().when().get("/v1/m/travel_region/get_booking_cat_card/"+exchangeId+"/0").then().statusCode(200);
    }

    @Test
    public void getBookingPkgListByExchId() {
        given().when().get("/v1/m/travel_region/get_fixed_pkg_cards_all/47/0").then().statusCode(200);
    }


    @Test
    public void getBookingPkgCardByPkgId() {
        given().when().get("/v1/m/travel_region/get_fixed_pkg_card_by_id/78").then().statusCode(200);
    }

    @Test
    public void getBookingPkgAllByEchId() {
        given().when().get("/v1/m/travel_region/get_fixed_pkg_detail_all/47").then().statusCode(200);
    }

    @Test
    public void getBookingPkgDetById() {
        given().when().get("/v1/m/travel_region/get_fixed_pkg_detail/78/0").then().statusCode(200);
    }

    @Test
    public void getBookingPlanListByExchId() {
        given().when().get("/v1/m/travel_region/get_rtrip_card_all/47/0").then().statusCode(200);
    }

    @Test
    public void getBookingPlanCardById() {
        given().when().get("/v1/m/travel_region/get_rtrip_card_by_id/181").then().statusCode(200);
    }

    @Test
    public void getBookingPlanDetById() {
        given().when().get("/v1/m/travel_region/get_rtrip_card_detail/181/0").then().statusCode(200);
    }

    @Test
    public void getHelicopterPkgDetListByExchIdAndTripTypeId() {
        given().when().get("/v1/m/travel_region/get_helicopter_pd_pkg_card/2/5/0").then().statusCode(200);
    }

    @Test
    public void getRegionDetByRegionId() {
        given().when().get("/v1/m/travel_region/get_region_det_mob/91012702/0").then().statusCode(200);
    }


    @Test
    public void getBookingBusiPoliByserviceId() {
        given().when().get("/v1/m/business/get_policies/B1-20158791AB04000/27/0").then().statusCode(200);
    }

    @Test
    public void getBookingHldActPkgByExchId() {
        given().when().get("/v1/m/trippkg/holiday_act_packages/47/0").then().statusCode(200);
    }

    @Test
    public void getBookingHldActPkgByPkgId() {
        given().when().get("/v1/m/trippkg/holiday_act_packages/get_by_id/51").then().statusCode(200);
    }

    @Test
    public void getBookingHldActPkgDetByPkgId() {
        given().when().get("/v1/m/trippkg/holiday_act_packages/get_detail_by_id/51/0").then().statusCode(200);
    }

    @Test
    public void getPlaceDestListByExchId() {
        given().when().get("/v1/m/destinations/list/dest/47/0").then().statusCode(200);
    }

    @Test
    public void getPlaceDestCardByExchIdAndDestId() {
        given().when().get("/v1/m/destinations/dest/get_card/2/18").then().statusCode(200);
    }

    @Test
    public void getPlaceDestDetById() {
        given().when().get("/v1/m/destinations/dest/summary/47/49/3/0").then().statusCode(200);
    }

    @Test
    public void getPlacePoiDetById() {
        given().when().get("/v1/m/destinations/poi/summary/1470/0").then().statusCode(200);
    }


    @Test
    public void getPlaceRegionListByExchId() {
        given().when().get("/v1/m/travel_region/get_regions_card/47/0").then().statusCode(200);
    }

    @Test
    public void getPlaceRegionAreaListByExchId() {
        given().when().get("/v1/m/travel_region/get_regions_areas_card/47/0").then().statusCode(200);
    }

    @Test
    public void getPlaceRegionAreaDetByAreaId() {
        given().when().get("/v1/m/travel_region/get_regions_area_det/47/3/0").then().statusCode(200);
    }

    @Test
    public void getNotificationTopicByExchId() {
        given().when().get("/v1/notification/m/get-topics/2/0").then().statusCode(200);
    }

    @Test
    public void getNotificationUpdateByExchId() {
        given().when().get("/v1/notification/m/sent_updates/47/true/0").then().statusCode(200);
    }

    @Test
    public void getInfoActDetById() {
        given().when().get("/v1/m/trippkg/get_infopkg_detail/146/0").then().statusCode(200);
    }

    @Test
    public void getAccListByCatId() {
        given().when().get("/v1/m/accomodation/get_accom_list_by_catg/320/0").then().statusCode(200);
    }

    @Test
    public void getAccCardByCatIdAccId() {
        given().when().get("/v1/m/accomodation/get_accom_card_by_id/0/HOMESTAY-201").then().statusCode(200);
    }

    @Test
    public void getAccHotelDetById() {
        given().when().get("/v1/m/accomodation/get_hotel_detail/208/0").then().statusCode(200);
    }

    @Test
    public void getAccHomestayDetById() {
        given().when().get("/v1/m/accomodation/get_homestay_detail/183/0").then().statusCode(200);
    }

    @Test
    public void getEstbShopDineListByExchAndDestId() {
        given().when().get("/v1/m/destinations/get_shop_and_dine/3/18/0").then().statusCode(200);
    }

    @Test
    public void getEstbShopDineCardById() {
        given().when().get("/v1/m/destinations/get_shop_and_dine_card/2").then().statusCode(200);
    }

    @Test
    public void getEstbShopDineDetById() {
        given().when().get("/v1/m/destinations/get_shop_and_dine_detail/2/0").then().statusCode(200);
    }

    @Test
    public void getEstbExchSpecilityByExchId() {
        given().when().get("/v1/m/destinations/get_exchange_specialities/47/0").then().statusCode(200);
    }


    @Test
    public void getActCatListByExchId() {
        given().when().get("/v1/m/trippkg/activitycat/get_by_exchange/47/0").then().statusCode(200);
    }

    @Test
    public void getActCatCardById() {
        given().when().get("/v1/m/trippkg/activitycat/get_by_id/53").then().statusCode(200);
    }

    @Test
    public void getActCardListByExchId() {
        given().when().get("/v1/m/trippkg/activitypkg/get_activities_cards_all/47/0").then().statusCode(200);
    }

    @Test
    public void getActCardById() {
        given().when().get("/v1/m/trippkg/activitypkg/get_activity_card/291").then().statusCode(200);
    }

    @Test
    public void getActDetByActId() {
        given().when().get("/v1/m/trippkg/activitypkg/get_activity_det/291/0").then().statusCode(200);
    }

    @Test
    public void getActCustFieldListByExchId() {
        given().when().get("/v1/m/trippkg/cust_fields/47/0").then().statusCode(200);
    }

    @Test
    public void getTravelDeskServiceItemByExchId() {
        given().when().get("/v1/m/trippkg/cust_fields/47/0").then().statusCode(200);
    }

    @Test
    public void getTravelDeskListItemByMapId() {
        given().when().get("/v1/m/travel_desk/list_items/170/0").then().statusCode(200);
    }

    @Test
    public void getTravelDeskSubGroupItemByMapId() {
        given().when().get("/v1/m/travel_desk/sub_group_items/87/0").then().statusCode(200);
    }

    @Test
    public void getTravelDeskMapDetByMapId() {
        given().when().get("/v1/m/travel_desk/mapping_details/82/0").then().statusCode(200);
    }

    @Test
    public void getTravelDeskAccItemByPlaceIdAndCatId() {
        given().when().get("/v1/m/travel_desk/get_accommodation_items/23/jvxg6pzm/0").then().statusCode(200);
    }

    @Test
    public void getExchDetByExchId() {
        given().when().get("/v1/m/exchange/get_detail/47/0").then().statusCode(200);
    }

    @Test
    public void getExpertListByExchId() {
        given().when().get("/v1/m/experts/experts/47/0").then().statusCode(200);
    }

    @Test
    public void getSPListByExchId() {
        given().when().get("/v1/m/experts/providers/47/0").then().statusCode(200);
    }






//Guide Related

    @Test
    public void getGuideIndexListExchId() {
        given().when().get("/v1/m/guides/get_index/47/0").then().statusCode(200);
    }

    @Test
    public void getGuideChapterDetByGidAndChId() {
        given().when().get("/v1/m/guides/get_chapter_flat/14/157/0").then().statusCode(200);
    }

    @Test
    public void getGuideChapterListByGidAndExchId() {
        given().when().get("/v1/m/guides/get_guide_flat/47/14/0").then().statusCode(200);
    }

    //Ecommerce

    @Test
    public void getEcommCatListByExchId() {
        given().when().get("/v1/m/ecomm/categories/47/0").then().statusCode(200);
    }

    @Test
    public void getEcommProdListByExchId() {
        given().when().get("/v1/m/ecomm/products/3/0").then().statusCode(200);
    }

    @Test
    public void getEcommProdDetByProdId() {
        given().when().get("/v1/m/ecomm/prod/51/0").then().statusCode(200);
    }

    @Test
    public void getEcommCustOrderByCustIdAndExchId() {
        given().when().get("/v1/m/order/get_orders/dW3nXs11ndO4Wn3zwZJAXmj57Vw2/22/0").then().statusCode(200);
    }

    @Test
    public void getEcommCustOrderDetByCustorderId() {
        given().when().get("/v1/m/order/get_ord_det/164/0").then().statusCode(200);
    }

    @Test
    public void getTransportServiceDetByExchId() {
        given().when().get("/v1/m/transport/transport_setup/47/0").then().statusCode(200);
    }

    @Test
    public void getTransportPkgListByRoute() {
        given().when().get("/v1/m/transport/transport_packages/57/0").then().statusCode(200);
    }



    // Queries secure_quotes
    @Test
    public void getQuoteByCustIdAndByExchId() {
        given().when().get("/v1/m/secure/quotes/get_all_quotes/dW3nXs11ndO4Wn3zwZJAXmj57Vw2/47/0").then().statusCode(200);
    }

    @Test
    public void getQuoteCardById() {
        given().when().get("/v1/m/secure/quotes/get_quote_short/752/0").then().statusCode(200);
    }

    @Test
    public void getQuoteDetById() {
        given().when().get("/v1/m/secure/quotes/get_quote/752/0").then().statusCode(200);
    }

    @Test
    public void getQuoteDetListByCustId() {
        given().when().get("/v1/m/secure/quotes/get_quotes_detail_by_customer/dW3nXs11ndO4Wn3zwZJAXmj57Vw2/0").then().statusCode(200);
    }

    @Test
    public void getVoucherCardByExchAndCustId() {
        given().when().get("/v1/secure/voucher/m/get_vouchers_short/22/dW3nXs11ndO4Wn3zwZJAXmj57Vw2/0").then().statusCode(200);
    }

    @Test
    public void getVoucherCardListByQryId() {
        given().when().get("/v1/m/secure/voucher/get_voucher_card_by_query/CQ636F372B2CD1000").then().statusCode(200);
    }

    @Test
    public void getVoucherDetListByQryId() {
        given().when().get("/v1/m/secure/voucher/voucher_details_by_query/CQ636F372B2CD1000/0").then().statusCode(200);
    }

    @Test
    public void getVoucherDetByVoucherRandId() {
        given().when().get("/v1/m/secure/voucher/detail/V4114D46D21A8000/0").then().statusCode(200);
    }

    @Test
    public void getActBookingDetailByBookingId() {
        given().when().get("/v1/m/ticket/booking/detail/119/0").then().statusCode(200);
    }

    @Test
    public void getTransportBookDetByBookingId() {
        given().when().get("/v1/m/transport/transport_booking/1/0").then().statusCode(200);
    }


    // Partner


    @Test
    public void getQuoteDetByQuoteId() {
        given().when().get("/v1/m/secure/quotes/get_quote_card/796").then().statusCode(200);
    }

    @Test
    public void getAllQuoteByBusiId() {
        given().when().get("/v1/m/secure/quotes/get_all_quotes_by_busi/B1-40D7E71B5DA8000/0").then().statusCode(200);
    }

    @Test
    public void getVoucherCardListByBusiId() {
        given().when().get("/v1/secure/voucher/m/get_vouchers_short_busi/B1-40D7E71B5DA8000/0").then().statusCode(200);
    }







}
